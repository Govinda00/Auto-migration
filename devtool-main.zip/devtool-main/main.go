package main

import (
	"devtool/cmd"
)

func main() {
	cmd.Execute()
}
